# Painting robot demo  

# For Painting Opreating


# Author:lz,zy,lh
