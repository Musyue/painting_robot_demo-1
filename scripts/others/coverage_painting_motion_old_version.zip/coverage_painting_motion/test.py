import sys
import os
o_path=os.getcwd()
sys.path.append()
print(sys.path)